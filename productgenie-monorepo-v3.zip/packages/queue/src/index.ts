
import Redis from "ioredis";
export type Job = { id: string; url: string; lang?: "tr"|"en" };
export class Queue {
  private redis: any;
  private stream: string;
  private group: string;
  constructor(url = "redis://127.0.0.1:6379", stream = "pg:jobs", group = "pg:grp") {
    // @ts-ignore
    this.redis = new Redis(url);
    this.stream = stream; this.group = group;
  }
  async init() { try { await this.redis.xgroup("CREATE", this.stream, this.group, "$", "MKSTREAM"); } catch (_) {} }
  async add(job: Job) { await this.redis.xadd(this.stream, "*", "job", JSON.stringify(job)); }
  async read(consumer: string, blockMs = 10000) {
    const res = await this.redis.xreadgroup("GROUP", this.group, consumer, "BLOCK", blockMs, "COUNT", 1, "STREAMS", this.stream, ">");
    if (!res) return null;
    const [_, entries] = res[0];
    const [id, fields] = entries[0];
    const data = JSON.parse(fields[1]);
    return { streamId: id, job: data as Job };
  }
  async ack(streamId: string) { await this.redis.xack(this.stream, this.group, streamId); }
}
