
import * as cheerio from "cheerio";
import { ParserKit, ParseResult } from "./contracts";

export const TrendyolKit: ParserKit = {
  domain: "trendyol.com",
  testUrls: ["https://www.trendyol.com/urun/ornek"],
  parse: (html: string, url: string): ParseResult => {
    const $ = cheerio.load(html);
    const title = $("h1.pr-new-br span, h1").first().text().trim();
    const priceText = $("span.prc-dsc, .pr-bx-w .prc").first().text().replace(/[^\d.,]/g, "");
    const price = Number((priceText || "0").replace(",", ".").match(/\d+(?:\.\d+)?/)?.[0] || 0);
    const rating = Number($(".rating-line .rate").first().text().replace(/[^\d.,]/g, "").replace(",", ".") || 0);
    const reviewCount = Number($("[data-testid='reviewCount']").text().replace(/\D/g, "") || 0);
    return { title, price: { value: price, currency: "TRY" }, rating, reviewCount };
  }
};
