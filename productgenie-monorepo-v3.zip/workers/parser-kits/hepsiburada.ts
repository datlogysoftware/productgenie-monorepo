
import * as cheerio from "cheerio";
import { ParserKit, ParseResult } from "./contracts";

export const HepsiburadaKit: ParserKit = {
  domain: "hepsiburada.com",
  testUrls: ["https://www.hepsiburada.com/ornek-urun"],
  parse: (html: string, url: string): ParseResult => {
    const $ = cheerio.load(html);
    const title = $("h1 [itemprop='name'], h1").first().text().trim();
    const priceText = $("[data-test-id='price-current-price'], .price, .extra-discounted").first().text().replace(/[^\d.,]/g, "");
    const price = Number((priceText || "0").replace(",", ".").match(/\d+(?:\.\d+)?/)?.[0] || 0);
    const rating = Number($("[itemprop='ratingValue']").attr("content") || 0);
    const reviewCount = Number($("[itemprop='reviewCount']").attr("content") || 0);
    return { title, price: { value: price, currency: "TRY" }, rating, reviewCount };
  }
};
