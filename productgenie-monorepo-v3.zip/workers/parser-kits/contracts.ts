
export type ParseResult = {
  title?: string;
  price?: { value: number; currency: string };
  sellerName?: string;
  rating?: number;
  reviewCount?: number;
};
export interface ParserKit {
  domain: string;
  testUrls: string[];
  parse: (html: string, url: string) => ParseResult;
}
