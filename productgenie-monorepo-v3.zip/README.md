
# ProductGenie Monorepo (MVP Scaffold v3)

pnpm workspaces · Next.js web · Express API · Extractor Worker · Orchestrator · Redis Streams · Mongo · Docker · CI

## Quick Start
```bash
corepack enable
corepack prepare pnpm@latest --activate
pnpm install

# Infra (Mongo + Redis)
docker compose -f infra/docker/docker-compose.yml up -d

# API (terminal-1)
export MONGO_URI=mongodb://127.0.0.1:27017
export REDIS_URL=redis://127.0.0.1:6379
export INGEST_TOKEN=dev-token
pnpm --filter services/api dev

# Orchestrator (terminal-2)
export API_BASE=http://localhost:3001
export REDIS_URL=redis://127.0.0.1:6379
export INGEST_TOKEN=dev-token
pnpm --filter services/orchestrator dev

# Web (terminal-3)
pnpm --filter apps/web dev
```
