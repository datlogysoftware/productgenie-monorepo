
import fetch from "node-fetch";
import pino from "pino";
import { Queue } from "@productgenie/queue";
import { extractUrl } from "@productgenie/extractor/src/index";

const log = pino({ name: "orchestrator" });
const queue = new Queue(process.env.REDIS_URL || "redis://127.0.0.1:6379");
await queue.init();

const API_BASE = process.env.API_BASE || "http://localhost:3001";
const INGEST_TOKEN = process.env.INGEST_TOKEN || "dev-token";

function heuristicScore(priceValue: number | undefined) {
  const authenticity = priceValue && priceValue > 0 ? 75 : 60;
  const seller = 66, store = 70, price = 62, review = 68;
  return { authenticity, seller, store, price, review };
}

async function run() {
  while (true) {
    const item = await queue.read("orchestrator-1", 10000);
    if (!item) continue;
    const { streamId, job } = item;
    try {
      const ext = await extractUrl(job.url);
      const criteria = heuristicScore(ext.price?.value);
      const positives = ["Sayfa erişilebilir", ext.title ? "Başlık tespit edildi" : ""];
      const cautions = [ext.price?.value ? "" : "Fiyat algılanamadı"];
      const payload = { criteria, positives: positives.filter(Boolean), cautions: cautions.filter(Boolean) };
      const r = await fetch(`${API_BASE}/v1/ingest/${job.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-ingest-token": INGEST_TOKEN },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error(`ingest failed ${r.status}`);
      log.info({ id: job.id, url: job.url, title: ext.title, price: ext.price }, "job processed");
      await queue.ack(streamId);
    } catch (e) {
      log.error({ err: e, job }, "job error");
    }
  }
}
run();
