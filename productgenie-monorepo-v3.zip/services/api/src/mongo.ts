
import { MongoClient, Db, Collection } from "mongodb";
import type { Analysis } from "@productgenie/shared";

let client: MongoClient | null = null;
let db: Db;
let analyses: Collection<Analysis>;

export async function connectMongo(uri: string, dbName: string = "productgenie") {
  if (client) return { db, analyses };
  client = new MongoClient(uri);
  await client.connect();
  db = client.db(dbName);
  analyses = db.collection<Analysis>("analyses");
  await analyses.createIndex({ id: 1 }, { unique: true });
  await analyses.createIndex({ createdAt: 1 });
  return { db, analyses };
}

export function collections() {
  if (!analyses) throw new Error("Mongo not connected");
  return { analyses };
}
