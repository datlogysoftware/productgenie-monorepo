
import { describe, it, expect } from 'vitest';
import { computeStars } from '../src/index';

describe('computeStars', () => {
  it('weights criteria correctly', () => {
    const c = { review: 100, authenticity: 0, seller: 0, store: 0, price: 0 };
    // 25% of 100 => 25 -> /20 = 1.25 -> 1.3 rounded to 1 decimal
    expect(computeStars(c)).toBe(1.3);
  });
});
