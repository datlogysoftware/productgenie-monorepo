
import { startTelemetry } from "@productgenie/telemetry";
await startTelemetry(process.env.OTEL_SERVICE_NAME || "productgenie-api");
