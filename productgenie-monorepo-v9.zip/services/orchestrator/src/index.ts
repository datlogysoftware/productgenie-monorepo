
import fetch from "node-fetch";
import pino from "pino";
import { Queue } from "@productgenie/queue";
import { extractUrl } from "@productgenie/extractor/src/index";
import { fetchRobots, isAllowed } from "@productgenie/robots";

const log = pino({ name: "orchestrator" });
const queue = new Queue(process.env.REDIS_URL || "redis://127.0.0.1:6379");
await queue.init();

const API_BASE = process.env.API_BASE || "http://localhost:3001";
const INGEST_TOKEN = process.env.INGEST_TOKEN || "dev-token";
const DEFAULT_DELAY = 1000; // 1 req/sec per domain

const domainState = new Map<string, { nextAt: number; crawlDelay: number }>();

function hostOf(u: string) { try { return new URL(u).hostname.replace(/^www\./,""); } catch { return "unknown"; } }
function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function respectRobotsAndThrottle(url: string) {
  const host = hostOf(url);
  let state = domainState.get(host);
  if (!state) {
    const rules = await fetchRobots(url);
    const delay = rules.crawlDelayMs ?? DEFAULT_DELAY;
    state = { nextAt: Date.now(), crawlDelay: delay };
    domainState.set(host, state);
  }
  const now = Date.now();
  if (now < state.nextAt) await sleep(state.nextAt - now);
  state.nextAt = Date.now() + state.crawlDelay;
}

function heuristicScore(priceValue: number | undefined) {
  const authenticity = priceValue && priceValue > 0 ? 78 : 60;
  const seller = 66, store = 70, price = 62, review = 68;
  return { authenticity, seller, store, price, review };
}


async function toDeadLetter(job: any, reason: string) {
  // Push to DLQ stream
  const { default: Redis } = await import("ioredis");
  // @ts-ignore
  const r = new Redis(process.env.REDIS_URL || "redis://127.0.0.1:6379");
  await r.xadd("pg:dead", "*", "job", JSON.stringify({ ...job, reason, ts: Date.now() }));
}

const MAX_ATTEMPTS = Number(process.env.MAX_JOB_ATTEMPTS || 3);

async function run() {
  while (true) {
    const item = await queue.read("orchestrator-1", 10000);
    if (!item) continue;
    const { streamId, job } = item;
    try {
      const rules = await fetchRobots(job.url);
      if (!isAllowed(job.url, rules)) {
        const payload = { positives: [], cautions: ["robots.txt bu yolu engelliyor"], criteria: { authenticity: 50, seller: 50, store: 50, price: 50, review: 50 } };
        await fetch(`${API_BASE}/v1/ingest/${job.id}`, { method: "POST", headers: { "Content-Type": "application/json", "x-ingest-token": INGEST_TOKEN }, body: JSON.stringify(payload) });
        log.warn({ url: job.url }, "blocked-by-robots");
        await queue.ack(streamId);
        continue;
      }
      await respectRobotsAndThrottle(job.url);
      const ext = await extractUrl(job.url);
      const criteria = heuristicScore(ext.price?.value);
      const positives = ["Sayfa erişilebilir", ext.title ? "Başlık tespit edildi" : ""];
      const cautions = [ext.price?.value ? "" : "Fiyat algılanamadı"];
      const payload = { criteria, positives: positives.filter(Boolean), cautions: cautions.filter(Boolean) };
      const r = await fetch(`${API_BASE}/v1/ingest/${job.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-ingest-token": INGEST_TOKEN },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error(`ingest failed ${r.status}`);
      log.info({ id: job.id, url: job.url, title: ext.title, price: ext.price }, "job processed");
      await queue.ack(streamId);
    } catch (e) {
      // attempt tracking
      // For simplicity, rely on Redis pending entries list IRL; here we enrich job with attempts
      const attempt = (job as any).attempt ? (job as any).attempt + 1 : 1;
      (job as any).attempt = attempt;
      if (attempt >= MAX_ATTEMPTS) {
        await toDeadLetter(job, (e as Error).message || "unknown");
        await queue.ack(streamId); // ack to avoid poison-pill
      }

      log.error({ err: e, job }, "job error");
    }
  }
}
run();
