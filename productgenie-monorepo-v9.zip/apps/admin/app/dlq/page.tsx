
"use client";
import { useEffect, useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";

export default function DLQ(){
  const [items, setItems] = useState<any[]>([]);
  const [err, setErr] = useState("");

  async function load(){
    setErr("");
    const token = localStorage.getItem("pg_admin_jwt") || "";
    const r = await fetch(`${API_BASE}/v1/admin/dlq?limit=200`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    if (!r.ok) { setErr("auth veya ağ hatası"); return; }
    const j = await r.json();
    setItems(j.items || []);
  }

  async function retry(xid: string){
    const token = localStorage.getItem("pg_admin_jwt") || "";
    await fetch(`${API_BASE}/v1/admin/dlq/retry`, {
      method: "POST", headers: { "Authorization": `Bearer ${token}`, "Content-Type":"application/json" },
      body: JSON.stringify({ xid })
    });
    load();
  }
  async function remove(xid: string){
    const token = localStorage.getItem("pg_admin_jwt") || "";
    await fetch(`${API_BASE}/v1/admin/dlq/${xid}`, { method: "DELETE", headers: { "Authorization": `Bearer ${token}` } });
    load();
  }

  useEffect(()=>{ load(); }, []);

  return (<main style={{maxWidth:1000,margin:'40px auto'}}>
    <h1 style={{fontSize:22,fontWeight:700,marginBottom:12}}>Dead Letter Queue</h1>
    <button onClick={load} style={{padding:'8px 12px', border:'1px solid #ddd', borderRadius:8}}>Yenile</button>
    {err && <p style={{color:'#b91c1c'}}>{err}</p>}
    <table style={{width:'100%',marginTop:16,borderCollapse:'collapse'}}>
      <thead><tr><th align="left">XID</th><th align="left">URL</th><th align="left">Attempt</th><th align="left">Sebep</th><th align="left">Aksiyon</th></tr></thead>
      <tbody>
        {items.map((x:any)=>(
          <tr key={x.xid} style={{borderTop:'1px solid #eee'}}>
            <td style={{padding:8}}>{x.xid}</td>
            <td style={{padding:8}}>{x.job?.url}</td>
            <td style={{padding:8}}>{x.job?.attempt ?? "-"}</td>
            <td style={{padding:8}}>{x.job?.reason ?? "-"}</td>
            <td style={{padding:8}}>
              <button onClick={()=>retry(x.xid)} style={{marginRight:8}}>Retry</button>
              <button onClick={()=>remove(x.xid)}>Sil</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </main>);
}
