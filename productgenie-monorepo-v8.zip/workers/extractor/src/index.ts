
import { chromium } from "playwright";
import pino from "pino";
import { normalizePrice } from "@productgenie/pcms";
import { selectKit } from "@productgenie/parsers";

const log = pino({ name: "extractor" });

export async function extractUrl(url: string) {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ userAgent: "ProductGenieBot/0.1 (+https://productgenie.example/bot)" });
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
  const html = await page.content();
  await browser.close();

  let title = "unknown";
  let price: { value: number; currency: string } | undefined;

  const kit = selectKit(url);
  if (kit) {
    try {
      const parsed = kit.parse(html, url);
      title = parsed.title || title;
      if (parsed.price) price = parsed.price;
    } catch (e) {
      log.warn({ err: e, url }, "kit-parse-failed");
    }
  } else {
    const m = html.replace(/<[^>]+>/g, " ").match(/(\d+[\.,]\d{2})\s*(TL|TRY|₺)/i);
    if (m) price = normalizePrice(Number(m[1].replace(",", ".")), "TRY");
    const t = html.match(/<title>([^<]+)<\/title>/i);
    if (t) title = t[1].trim();
  }

  return { title, price, snapshotBytes: html.length };
}

if (import.meta.main) {
  const url = process.argv[2] || "https://example.com";
  extractUrl(url).then(r => { log.info({ r }, "extracted"); }).catch(e => { log.error(e); process.exit(1); });
}
