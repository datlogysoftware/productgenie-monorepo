
import fetch from "node-fetch";

export type RobotsRules = {
  allows: string[];
  disallows: string[];
  crawlDelayMs?: number;
};

function parseRobotsTxt(txt: string, ua: string): RobotsRules {
  const lines = txt.split(/\r?\n/).map(l => l.trim());
  let currentUA: string[] = [];
  const rules: Record<string, RobotsRules> = {};

  for (const line of lines) {
    if (!line || line.startsWith("#")) continue;
    const [kRaw, ...vParts] = line.split(":");
    if (!kRaw || vParts.length === 0) continue;
    const key = kRaw.trim().toLowerCase();
    const val = vParts.join(":").trim();

    if (key === "user-agent") {
      const agent = val.toLowerCase();
      currentUA = [agent];
      rules[agent] = rules[agent] || { allows: [], disallows: [] };
    } else if (key === "allow") {
      for (const uaKey of currentUA) { (rules[uaKey] = rules[uaKey] || { allows: [], disallows: [] }).allows.push(val); }
    } else if (key === "disallow") {
      for (const uaKey of currentUA) { (rules[uaKey] = rules[uaKey] || { allows: [], disallows: [] }).disallows.push(val); }
    } else if (key === "crawl-delay") {
      const ms = Math.max(0, Math.floor(Number(val) * 1000));
      for (const uaKey of currentUA) { (rules[uaKey] = rules[uaKey] || { allows: [], disallows: [] }).crawlDelayMs = ms; }
    }
  }

  // merge precedence: exact UA, wildcard ProductGenieBot, then '*'.
  const wanted = [ua.toLowerCase(), "productgeniebot", "productgeniebot/0.1", "*"];
  const merged: RobotsRules = { allows: [], disallows: [] };
  for (const w of wanted) {
    if (rules[w]) {
      merged.allows.push(...rules[w].allows);
      merged.disallows.push(...rules[w].disallows);
      if (rules[w].crawlDelayMs !== undefined) merged.crawlDelayMs = rules[w].crawlDelayMs;
    }
  }
  return merged;
}

export async function fetchRobots(u: string, ua = "ProductGenieBot/0.1"): Promise<RobotsRules> {
  let host = "";
  try { host = new URL(u).origin; } catch { return { allows: [], disallows: [] }; }
  try {
    const r = await fetch(host + "/robots.txt", { redirect: "follow" as any, timeout: 8000 as any });
    if (!r.ok) return { allows: [], disallows: [] };
    const txt = await r.text();
    return parseRobotsTxt(txt, ua);
  } catch {
    return { allows: [], disallows: [] };
  }
}

export function isAllowed(u: string, rules: RobotsRules): boolean {
  try {
    const url = new URL(u);
    const path = url.pathname;
    // simple prefix match; Allow beats Disallow if longer
    const dis = rules.disallows || [];
    const alw = rules.allows || [];
    let blocked = false; let longestBlock = "";
    for (const d of dis) {
      if (d && path.startsWith(d) && d.length > longestBlock.length) { blocked = true; longestBlock = d; }
    }
    for (const a of alw) {
      if (a && path.startsWith(a) && a.length >= longestBlock.length) { blocked = false; }
    }
    return !blocked;
  } catch { return true; }
}
