# ProductGenie Repo (placeholder if v3 missing)\n

## Sprint 3 Notes
- Parsers: @productgenie/parsers (hepsiburada, trendyol) — Extractor hostname ile seçer.
- API: /v1/analyze için IP başına 1 dk'da 30 istek (in-memory).
- Admin: /v1/admin/analyses (header: x-admin-token, env: ADMIN_TOKEN).

### Admin panel
```bash
export NEXT_PUBLIC_API_BASE=http://localhost:3001
export NEXT_PUBLIC_ADMIN_TOKEN=dev-admin
pnpm --filter apps/admin dev  # http://localhost:3002
```


## Sprint 4 — robots.txt & Domain Rate + E2E
- **Robots uyumu:** `@productgenie/robots` paketi ile `User-agent: ProductGenieBot` ve `*` kuralları.
- **Per-domain throttle:** Orchestrator, `Crawl-delay` veya varsayılan 1 req/sn sınırına uyar.
- **E2E duman testleri (Playwright):**
  ```bash
  pnpm --filter tests/e2e install
  pnpm --filter tests/e2e test
  ```
  > Not: Testler `http://localhost:3000` (web) ve `http://localhost:3001` (API) açıkken çalışır.



## Sprint 5 — AuthN/AuthZ + Redis Rate Limit + Cache + Docker
- **Admin JWT**: `/v1/admin/login` → { token }. `Authorization: Bearer <token>` ile `/v1/admin/*` çağrıları.
- **Redis Rate Limit**: IP başı dakikada `RATE_LIMIT_PER_MIN` (varsayılan 60).
- **URL Cache**: Aynı URL için tekrar analizde mevcut `id` döner; TTL `CACHE_TTL_SECONDS`. İptal için:
  ```bash
  curl -X POST http://localhost:3001/v1/admin/cache/invalidate \
    -H "Authorization: Bearer $JWT" -H "Content-Type: application/json" \
    -d '{"url":"https://ornek.com/urun/123"}'
  ```
- **Docker**: `docker-compose.prod.yml` ile api+orchestrator+web+admin+mongo+redis.
  ```bash
  docker compose -f docker-compose.prod.yml up --build
  ```


## Sprint 6 — RBAC + MFA + Observability
- **JWT RBAC**: roles → `admin`, `analyst` (şu an admin kullanılıyor).
- **MFA (TOTP) desteği**: `TOTP_SECRET` tanımlandığında `/v1/admin/login` `code` alanını ister.
- **Argon2 hash**: `ADMIN_PASS_HASH` verildiğinde parola doğrulama hash ile yapılır.
- **Prometheus metrics**: `/metrics` (örn. `pg_analyze_requests_total`).
- **OpenTelemetry**: OTLP HTTP exporter endpoint’i (opsiyonel) ile iz.


## Sprint 7 — Production & CI/CD & Tests
- **Production Docker**: multi-stage build, `next start` ile web/admin prod.
- **CI (ci.yml)**: pnpm install → build → vitest test.
- **Docker pipeline (docker.yml)**: GHCR'a image push (örn. `ghcr.io/<owner>/productgenie-api:latest`).
- **DLQ**: orchestrator hata denemeleri `MAX_JOB_ATTEMPTS` sonrasında `pg:dead` stream'ine düşürür.
- **Global error handler**: API 500 durumlarını JSON olarak döner.
- **Unit tests**: `pnpm -r test` ile shared/parsers/auth testleri.
