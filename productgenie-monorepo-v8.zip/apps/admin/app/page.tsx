
"use client";
import { useEffect, useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";
const ADMIN_TOKEN = process.env.NEXT_PUBLIC_ADMIN_TOKEN || "dev-admin";
export default function Admin(){
  const [items,setItems]=useState<any[]>([]);
  const [loading,setLoading]=useState(true);
  async function load(){ setLoading(true); const r=await fetch(`${API_BASE}/v1/admin/analyses`,{headers:{'x-admin-token':ADMIN_TOKEN}}).then(r=>r.json()); setItems(r.items||[]); setLoading(false); }
  useEffect(()=>{ load(); },[]);
  return (<main style={{maxWidth:960,margin:'40px auto'}}>
    <h1 style={{fontSize:24,fontWeight:700,marginBottom:12}}>Admin — Analizler</h1>
    <button onClick={load} style={{padding:'8px 12px',border:'1px solid #ddd',borderRadius:8}}>Yenile</button>
    {loading? <p>Yükleniyor…</p> : (
      <table style={{width:'100%',marginTop:16,borderCollapse:'collapse'}}>
        <thead><tr><th align='left'>Tarih</th><th align='left'>URL</th><th align='left'>Skor</th></tr></thead>
        <tbody>{items.map((x:any)=>(<tr key={x.id} style={{borderTop:'1px solid #eee'}}><td style={{padding:'8px 6px'}}>{new Date(x.createdAt).toLocaleString()}</td><td style={{padding:'8px 6px'}}>{x.url}</td><td style={{padding:'8px 6px'}}>{x.totalScore}</td></tr>))}</tbody>
      </table>
    )}
  </main>);
}
