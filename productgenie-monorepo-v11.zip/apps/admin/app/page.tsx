
"use client";
import Link from "next/link";
export default function Home(){
  return (<main style={{maxWidth:960,margin:'40px auto'}}>
    <h1 style={{fontSize:28,fontWeight:800,marginBottom:12}}>ProductGenie — Admin</h1>
    <p style={{color:'#555'}}>Operasyon panosu</p>
    <ul style={{marginTop:16, listStyle:'disc', paddingLeft:20}}>
      <li><Link href="/login">Login</Link></li>
      <li><Link href="/analyses">Analiz Listesi</Link></li>
      <li><Link href="/dlq">DLQ (Dead Letter Queue)</Link></li>
    </ul>
  </main>);
}
