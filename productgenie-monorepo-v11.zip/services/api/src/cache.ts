
import crypto from "node:crypto";
import { redis } from "./redis";

function keyForUrl(url: string) {
  const h = crypto.createHash("sha256").update(url).digest("hex").slice(0, 16);
  return `pg:url:${h}`;
}

export async function cacheGetIdByUrl(url: string): Promise<string | null> {
  const r = redis();
  const id = await r.get(keyForUrl(url));
  return id;
}

export async function cacheSetIdByUrl(url: string, id: string, ttlSec = Number(process.env.CACHE_TTL_SECONDS || 86400)) {
  const r = redis();
  await r.set(keyForUrl(url), id, "EX", ttlSec);
}

export async function cacheInvalidateUrl(url: string) {
  const r = redis();
  await r.del(keyForUrl(url));
}
