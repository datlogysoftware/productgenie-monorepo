
import type { Collection } from "mongodb";

export interface PriceSample { domain: string; title?: string; url: string; price: number; createdAt: string; }

export async function createIndexes(col: Collection<PriceSample>) {
  await col.createIndex({ domain: 1, createdAt: -1 });
  await col.createIndex({ url: 1 });
}

export function domainOf(u: string): string {
  try { return new URL(u).hostname.replace(/^www\./,''); } catch { return "unknown"; }
}
