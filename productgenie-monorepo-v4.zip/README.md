# ProductGenie Repo (placeholder if v3 missing)\n

## Sprint 3 Notes
- Parsers: @productgenie/parsers (hepsiburada, trendyol) — Extractor hostname ile seçer.
- API: /v1/analyze için IP başına 1 dk'da 30 istek (in-memory).
- Admin: /v1/admin/analyses (header: x-admin-token, env: ADMIN_TOKEN).

### Admin panel
```bash
export NEXT_PUBLIC_API_BASE=http://localhost:3001
export NEXT_PUBLIC_ADMIN_TOKEN=dev-admin
pnpm --filter apps/admin dev  # http://localhost:3002
```
