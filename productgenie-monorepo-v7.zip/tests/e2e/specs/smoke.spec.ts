
import { test, expect } from '@playwright/test';

test('Web ana sayfa açılıyor ve analiz butonu görülebiliyor', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('ProductGenie')).toBeVisible();
  await expect(page.getByRole('button', { name: /Analiz Et/i })).toBeVisible();
});

test('API status döndürüyor', async ({}) => {
  const res = await fetch('http://localhost:3001/v1/status');
  expect(res.ok).toBeTruthy();
  const j = await res.json();
  expect(j.ok).toBeTruthy();
});
