
export async function connectMongo(){}
export function collections(){ return { analyses: { insertOne: async()=>{}, findOne: async()=>null, updateOne: async()=>{} } } as any}
