
import Redis from "ioredis";
let client: Redis | null = null;
export function redis(url = process.env.REDIS_URL || "redis://127.0.0.1:6379") {
  // @ts-ignore
  if (!client) client = new Redis(url);
  return client;
}
