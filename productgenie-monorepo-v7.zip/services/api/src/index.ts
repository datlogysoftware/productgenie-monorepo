
import "./otel-bootstrap"; // start otel
import express from "express";
import cors from "cors";
import pino from "pino";
import { randomUUID } from "node:crypto";
import { computeStars, type Analysis } from "@productgenie/shared";
import { Queue } from "@productgenie/queue";
import { connectMongo, collections } from "./mongo";
import { redis } from "./redis";
import { cacheGetIdByUrl, cacheSetIdByUrl, cacheInvalidateUrl } from "./cache";
import { signJWT, verifyTOTP } from "@productgenie/auth";
import { requireRole } from "./auth";
import argon2 from "argon2";
import client from "prom-client";

const app = express();
const log = pino({ name: "api" });
app.use(cors()); app.use(express.json());

const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017";
const REDIS_URL = process.env.REDIS_URL || "redis://127.0.0.1:6379";
const INGEST_TOKEN = process.env.INGEST_TOKEN || "dev-token";
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "admin";
const ADMIN_PASS_HASH = process.env.ADMIN_PASS_HASH || ""; // Argon2 hash opsiyonel
const TOTP_SECRET = process.env.TOTP_SECRET || ""; // MFA opsiyonel

const queue = new Queue(REDIS_URL);
queue.init();
connectMongo(MONGO_URI).catch(err=>{ log.error(err, "Mongo connect failed"); process.exit(1); });

// Redis-based rate limit (fixed window)
async function rateLimit(req: any, res: any, next: any) {
  const ip = (req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anon');
  const key = `pg:rl:${ip}:1m`;
  const r = redis();
  const limit = Number(process.env.RATE_LIMIT_PER_MIN || 60);
  const ttl = 60;
  const cur = await r.incr(key);
  if (cur === 1) await r.expire(key, ttl);
  if (cur > limit) {
    const ttlLeft = await r.ttl(key);
    return res.status(429).json({ error: "rate_limited", retryAfterSec: ttlLeft });
  }
  next();
}

// Prometheus metrics
const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics();
const analyzeCounter = new client.Counter({ name: "pg_analyze_requests_total", help: "Total analyze POST requests" });
app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", client.register.contentType);
  res.end(await client.register.metrics());
});

// Admin login → JWT (RBAC + MFA optional + Argon2)
app.post("/v1/admin/login", async (req, res) => {
  const { username, password, code } = req.body || {};
  if (username !== ADMIN_USER) return res.status(401).json({ error: "invalid_credentials" });
  if (ADMIN_PASS_HASH) {
    const ok = await argon2.verify(ADMIN_PASS_HASH, password || "");
    if (!ok) return res.status(401).json({ error: "invalid_credentials" });
  } else {
    if (password !== ADMIN_PASS) return res.status(401).json({ error: "invalid_credentials" });
  }
  if (TOTP_SECRET) {
    if (!code || !verifyTOTP(code, TOTP_SECRET)) return res.status(401).json({ error: "mfa_required_or_invalid" });
  }
  const token = signJWT(username, "admin", JWT_SECRET, Number(process.env.JWT_TTL_SECONDS || 3600));
  res.json({ token });
});

// Analyze: cache by URL
app.post("/v1/analyze", rateLimit, async (req, res) => {
  analyzeCounter.inc();
  const { url, lang = "tr" } = req.body || {};
  if (!url) return res.status(400).json({ error: "url is required" });

  const cachedId = await cacheGetIdByUrl(url);
  if (cachedId) return res.json({ id: cachedId, status: "cached" });

  const id = randomUUID();
  const criteria = { authenticity: 60, seller: 65, store: 70, price: 62, review: 68 };
  const analysis: Analysis = {
    id, url, criteria,
    totalScore: computeStars(criteria),
    positives: ["Yorum kalitesi iyi", "Mağaza puanı ortalama üstü", "Fiyat oynaklığı düşük"],
    cautions: ["Satıcı yeni", "Orijinallik kanıtı sınırlı", "Fiyat rekabetçiliği orta"],
    explain: [{ key: "authenticity", why: "marka kataloğu eşleşmesi zayıf" }],
    createdAt: new Date().toISOString()
  };
  const { analyses } = collections();
  await analyses.insertOne(analysis);
  await cacheSetIdByUrl(url, id);
  await queue.add({ id, url, lang });
  res.json({ id, status: "processing" });
});

app.get("/v1/analyses/:id", async (req, res) => {
  const { analyses } = collections();
  const a = await analyses.findOne({ id: req.params.id });
  if (!a) return res.status(404).json({ error: "not found" });
  res.json(a);
});

// Ingest
app.post("/v1/ingest/:id", async (req, res) => {
  const token = req.header("x-ingest-token");
  if (!INGEST_TOKEN || token !== INGEST_TOKEN) return res.status(401).json({ error: "unauthorized" });
  const { id } = req.params; const patch = req.body || {};
  const { analyses } = collections();
  const existing = await analyses.findOne({ id });
  if (!existing) return res.status(404).json({ error: "not found" });
  const next: Analysis = { ...existing, ...patch, criteria: patch.criteria || existing.criteria, totalScore: patch.criteria ? computeStars(patch.criteria) : existing.totalScore };
  await analyses.updateOne({ id }, { $set: next });
  res.json({ ok: true });
});

// Admin secured endpoints
app.get("/v1/admin/analyses", requireRole("admin"), async (req, res) => {
  const limit = Math.min(Number(req.query.limit || 50), 200);
  const { analyses } = collections();
  const items = await analyses.find({}, { sort: { createdAt: -1 } }).limit(limit).toArray();
  res.json({ items });
});

app.post("/v1/admin/cache/invalidate", requireRole("admin"), async (req, res) => {
  const { url } = req.body || {};
  if (!url) return res.status(400).json({ error: "url required" });
  await cacheInvalidateUrl(url);
  res.json({ ok: true });
});

app.get("/v1/status", (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

const port = process.env.PORT || 3001;
app.listen(port, () => log.info(`API listening on :${port}`));
