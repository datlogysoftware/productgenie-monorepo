
export const metadata = { title: "ProductGenie Admin", description: "Ops dashboard" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="tr"><body style={{fontFamily:'Inter, system-ui, sans-serif', background:'#f7f7f8', color:'#111'}}>{children}</body></html>);
}
