
"use client";
import { useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";
export default function Register(){
  const [email,setE]=useState(""); const [password,setP]=useState(""); const [premium,setPr]=useState(false); const [msg,setMsg]=useState("");
  async function submit(e:any){ e.preventDefault(); setMsg("");
    const r=await fetch(`${API_BASE}/v1/auth/signup`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password,premium})});
    const j=await r.json(); if(!r.ok){ setMsg(j.error||"signup_failed"); return;}
    setMsg("Kayıt başarılı, şimdi giriş yapabilirsiniz."); setTimeout(()=>location.href="/login",1000);
  }
  return (<main className="mx-auto max-w-sm py-12"><h1 className="text-2xl font-bold mb-4">Kayıt ol</h1>
    {msg && <p className="text-blue-700">{msg}</p>}
    <form onSubmit={submit} className="grid gap-2">
      <input className="border rounded px-3 py-2" placeholder="E-posta" value={email} onChange={e=>setE(e.target.value)} />
      <input className="border rounded px-3 py-2" placeholder="Şifre" type="password" value={password} onChange={e=>setP(e.target.value)} />
      <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={premium} onChange={e=>setPr(e.target.checked)} /> Premium</label>
      <button className="bg-black text-white rounded px-3 py-2" type="submit">Kayıt ol</button>
    </form>
  </main>);
}
