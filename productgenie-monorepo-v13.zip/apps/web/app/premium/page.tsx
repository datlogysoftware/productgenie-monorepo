
"use client";
import { useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";

export default function Premium(){
  const [err,setErr]=useState(""); const [loading,setL]=useState(false);
  async function go(){ setErr(""); setL(true);
    try{
      const token = localStorage.getItem("pg_user_jwt") || "";
      const r = await fetch(`${API_BASE}/v1/billing/checkout`, { method:'POST', headers:{ 'Authorization': `Bearer ${token}` } });
      const j = await r.json();
      if(!r.ok){ setErr(j.error||'checkout_failed'); setL(false); return; }
      if(j.url) location.href = j.url;
    }catch(e:any){ setErr(String(e)); setL(false); }
  }
  return (<main className="mx-auto max-w-md py-12">
    <h1 className="text-2xl font-bold mb-2">Premium</h1>
    <p className="text-sm text-gray-600 mb-4">PDF rapor ve gelişmiş analizlere erişim için Premium’a geçin.</p>
    <button onClick={go} disabled={loading} className="bg-black text-white rounded px-4 py-2">{loading?'Yönlendiriliyor…':'Stripe Checkout'a Git'}</button>
    {err && <p className="text-red-600 mt-3">{err}</p>}
  </main>);
}
