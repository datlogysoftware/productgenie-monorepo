
"use client";

function TrendChart({series}:{series:{t:string; v:number}[]}){
  if(!series.length) return null;
  const W=360,H=120,P=10; const min=Math.min(...series.map(s=>s.v)); const max=Math.max(...series.map(s=>s.v));
  const xs = (i:number)=> P + i*( (W-2*P)/Math.max(1,series.length-1) );
  const ys = (v:number)=> H-P - ( (v-min)/Math.max(1,(max-min)) )*(H-2*P);
  const pts = series.map((s,i)=> `${xs(i)},${ys(s.v)}`).join(' ');
  return (<svg width={W} height={H} className="block"><polyline points={pts} fill="none" stroke="#0ea5e9" strokeWidth={2}/></svg>);
}


function Radar({values}:{values:{authenticity:number; seller:number; store:number; price:number; review:number}}){
  const keys = ["authenticity","seller","store","price","review"] as const;
  const pts = keys.map((k,i)=>{
    const angle = (Math.PI*2/keys.length)*i - Math.PI/2; // start top
    const r = (values[k]/100)*60; // radius up to 60
    const x = 70 + r * Math.cos(angle);
    const y = 70 + r * Math.sin(angle);
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={140} height={140} className="block">
      <circle cx={70} cy={70} r={62} fill="none" stroke="#eee" />
      <polygon points="70,8 128,70 70,132 12,70" fill="none" stroke="#ddd" />
      <polyline points={pts} fill="rgba(59,130,246,0.15)" stroke="rgba(59,130,246,1)" strokeWidth={2} />
    </svg>
  );
}

import { useState, useEffect } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";
export default function Home(){
  const [isPremium,setIsPremium]=useState<boolean>(false);
  useEffect(()=>{ (async()=>{ try{ const t=localStorage.getItem('pg_user_jwt')||''; if(!t) return; const r=await fetch((process.env.NEXT_PUBLIC_API_BASE||'http://localhost:3001')+'/v1/user/me',{headers:{Authorization:'Bearer '+t}}); if(r.ok){ const j=await r.json(); setIsPremium(!!j.premium); } }catch{} })(); },[]);
  const isPremium = (typeof window!=='undefined' && localStorage.getItem('pg_user_jwt')) ? undefined : false;
  const [url,setUrl]=useState(""); const [result,setResult]=useState<any>(null); const [id,setId]=useState<string|null>(null);
  async function analyze(){
    const r = await fetch(`${API_BASE}/v1/analyze`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url,lang:"tr"})}).then(r=>r.json());
    setId(r.id);
    for(let i=0;i<15;i++){ const a = await fetch(`${API_BASE}/v1/analyses/${r.id}`).then(r=>r.json()); setResult(a); await new Promise(s=>setTimeout(s,1000)); }
  }
  return (<main className="mx-auto max-w-2xl py-12">
    <h1 className="text-3xl font-bold mb-2">ProductGenie</h1>
    <p className="mb-6 text-sm text-gray-600">Satın almadan önce kontrol et — güvenle alışveriş yap.</p>
    <div className="flex gap-2"><input className="flex-1 border rounded px-3 py-2" value={url} onChange={e=>setUrl(e.target.value)} placeholder="Ürün URL'si" /><button onClick={analyze} className="px-4 py-2 bg-black text-white rounded">Analiz Et</button></div>
    {result && (<div className="mt-8 border rounded p-4 bg-white">
      
        <h2 className="font-semibold mb-2">Skor: {result.totalScore} / 5</h2>
        <div className="flex items-center gap-2 mb-2">
          <div aria-label="stars" className="text-amber-500 text-xl">{'★'.repeat(Math.round(result.totalScore))}{'☆'.repeat(5-Math.round(result.totalScore))}</div>
        <div className="flex items-center gap-3 mt-2">
          <span className="text-xs bg-indigo-100 text-indigo-700 rounded px-2 py-0.5">Kategori: {(result.category||'default')}</span>
          <Radar values={result.criteria} />
        </div>
          <span className="text-xs bg-green-100 text-green-700 rounded px-2 py-0.5">Güven bandı (MVP)</span>
        </div>
        <div className="flex items-center gap-3 mt-2">
          <span className="text-xs bg-indigo-100 text-indigo-700 rounded px-2 py-0.5">Kategori: {(result.category||'default')}</span>
          <Radar values={result.criteria} />
        </div>
        
      <ul className="text-sm grid grid-cols-2 gap-2">
        <li>Orijinallik: {result.criteria.authenticity}</li><li>Satıcı: {result.criteria.seller}</li>
        <li>Mağaza: {result.criteria.store}</li><li>Fiyat: {result.criteria.price}</li>
        <li>Yorum: {result.criteria.review}</li>
      </ul>
      <div className="mt-3"><h3 className="font-medium">Olumlu</h3><ul className="list-disc ml-6 text-sm">{result.positives?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul></div>
      <div className="mt-3"><h3 className="font-medium">Dikkat</h3><ul className="list-disc ml-6 text-sm">{result.cautions?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul></div>
    </div>)}
  {id && isPremium && (<div className="mt-4"><a className="underline text-blue-600" href={`${API_BASE}/v1/analyses/${id}/report.pdf`} target="_blank" rel="noreferrer">PDF indir (Premium)</a></div>)}
      {!isPremium && id && (<p className="text-xs text-gray-600 mt-2">PDF indirme Premium kullanıcılara açıktır. <a className='underline' href='/premium'>Premium'a geç</a></p>)}
  </main>);
}
