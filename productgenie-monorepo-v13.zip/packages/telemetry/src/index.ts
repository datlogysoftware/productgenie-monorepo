
import { NodeSDK } from "@opentelemetry/sdk-node";
import { getNodeAutoInstrumentations } from "@opentelemetry/auto-instrumentations-node";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-http";

let sdk: NodeSDK | null = null;

export async function startTelemetry(serviceName: string) {
  if (sdk) return;
  const url = process.env.OTEL_EXPORTER_OTLP_TRACES_ENDPOINT || "";
  const exporter = url ? new OTLPTraceExporter({ url }) : undefined;
  sdk = new NodeSDK({
    serviceName,
    traceExporter: exporter,
    instrumentations: [getNodeAutoInstrumentations()]
  });
  await sdk.start();
  process.on("SIGTERM", async () => { await sdk?.shutdown(); process.exit(0); });
}

export async function stopTelemetry() { await sdk?.shutdown(); sdk = null; }
