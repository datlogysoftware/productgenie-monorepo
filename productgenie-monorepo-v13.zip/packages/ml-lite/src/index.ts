
export type Category = "default" | "electronics" | "fashion" | "cosmetics" | "grocery";
export type Weights = Record<Category, Record<string, number>>;

const BASE: Weights = {
  electronics: { iphone:3, samsung:2, xiaomi:2, tv:2, laptop:2, macbook:3, ipad:2, playstation:2, ps5:3, airpods:2, ssd:2, monitor:2 },
  fashion: { elbise:3, tshirt:2, "t-shirt":2, pantolon:2, sneaker:2, ayakkabı:2, çanta:2, gomlek:2, mont:2, ceket:2, etek:2, triko:2 },
  cosmetics: { parfüm:3, parfum:3, kolonya:2, serum:2, krem:2, maskara:2, ruj:2, fondöten:2, tonik:2, "güneş":2, sunscreen:2, şampuan:2, sampuan:2 },
  grocery: { pirinç:2, bulgur:2, zeytinyağı:3, zeytinyagi:3, un:2, şeker:2, seker:2, kahve:2, çay:2, cay:2, makarna:2, yağ:2, yag:2, bakliyat:2, peynir:2 },
  default: {}
};

export function mergeWeights(custom?: Partial<Weights>): Weights {
  if (!custom) return BASE;
  const out: Weights = JSON.parse(JSON.stringify(BASE));
  for (const cat of Object.keys(custom) as (keyof Weights)[]) {
    out[cat] = { **out[cat], **(custom[cat] || {}) } as any;
  }
  return out;
}

export function classifyCategory(texts: string[], weights?: Partial<Weights>): Category {
  const W = mergeWeights(weights);
  const t = texts.join(" ").toLowerCase();
  let best: Category = "default"; let bestScore = 0;
  (Object.keys(W) as Category[]).forEach((cat)=>{
    let s = 0; for (const [k, w] of Object.entries(W[cat])) { if (t.includes(k)) s += w; }
    if (s > bestScore) { bestScore = s; best = cat; }
  });
  return best;
}
