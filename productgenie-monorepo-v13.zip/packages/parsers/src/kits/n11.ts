
import * as cheerio from "cheerio";
import { ParserKit, ParseResult } from "../contracts";

export const N11Kit: ParserKit = {
  domain: "n11.com",
  testUrls: ["https://www.n11.com/urun/ornek"],
  parse: (html: string, url: string): ParseResult => {
    const $ = cheerio.load(html);
    const title = $("h1, .proName").first().text().trim();
    const priceText = $(".newPrice ins, .price, [itemprop='price']").first().text().replace(/[^\d.,]/g, "");
    const price = Number((priceText || "0").replace(",", ".").match(/\d+(?:\.\d+)?/)?.[0] || 0);
    const rating = Number($("[itemprop='ratingValue']").attr("content") || 0);
    const reviewCount = Number($("[itemprop='reviewCount']").attr("content") || 0);
    return { title, price: { value: price, currency: "TRY" }, rating, reviewCount };
  }
};
