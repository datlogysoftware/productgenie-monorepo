
import { describe, it, expect } from 'vitest';
import { selectKit } from '../src/index';

describe('selectKit', () => {
  it('matches hepsiburada', () => {
    expect(selectKit('https://www.hepsiburada.com/urun/x')?.domain).toBe('hepsiburada.com');
  });
  it('matches trendyol', () => {
    expect(selectKit('https://trendyol.com/urun/x')?.domain).toBe('trendyol.com');
  });
  it('returns null for unknown', () => {
    expect(selectKit('https://example.com/foo')).toBeNull();
  });
});
