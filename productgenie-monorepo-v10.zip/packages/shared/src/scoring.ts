
export type Category = "default" | "electronics" | "fashion" | "cosmetics" | "grocery";

export type Criteria = {
  authenticity: number; seller: number; store: number; price: number; review: number;
};

export const CATEGORY_WEIGHTS: Record<Category, Criteria> = {
  default:     { review:25, authenticity:25, seller:20, store:15, price:15 } as any,
  electronics: { review:20, authenticity:30, seller:20, store:15, price:15 } as any,
  fashion:     { review:25, authenticity:25, seller:15, store:20, price:15 } as any,
  cosmetics:   { review:25, authenticity:30, seller:15, store:15, price:15 } as any,
  grocery:     { review:20, authenticity:20, seller:20, store:20, price:20 } as any,
};

export function computeWeightedStars(c: Criteria, cat: Category = "default"): number {
  const w = CATEGORY_WEIGHTS[cat] || CATEGORY_WEIGHTS.default;
  const weighted = (w.review/100)*c.review + (w.authenticity/100)*c.authenticity + (w.seller/100)*c.seller + (w.store/100)*c.store + (w.price/100)*c.price;
  return Math.round(((weighted/20) * 10)) / 10;
}

export function confidenceFromSignals(signals: { hasPrice?: boolean; parsedTitle?: boolean; robotsBlocked?: boolean; domainKnown?: boolean; reviewSignals?: number }): number {
  let score = 50;
  if (signals.hasPrice) score += 10;
  if (signals.parsedTitle) score += 10;
  if (signals.domainKnown) score += 10;
  score += Math.min(20, Math.max(0, (signals.reviewSignals || 0)));
  if (signals.robotsBlocked) score -= 30;
  return Math.max(0, Math.min(100, score));
}
