
import { describe, it, expect } from 'vitest';
import { signJWT, verifyJWT } from '../src/index';

describe('JWT', () => {
  it('signs and verifies', () => {
    const token = signJWT('u','admin','secret', 60);
    const claims = verifyJWT(token, 'secret');
    expect(claims?.sub).toBe('u');
    expect(claims?.role).toBe('admin');
  });
});
