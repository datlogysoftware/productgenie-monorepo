
import jwt from "jsonwebtoken";
import { authenticator } from "otplib";

export type Role = "admin" | "analyst";
export type Claims = { sub: string; role: Role; iat?: number; exp?: number };

export function signJWT(username: string, role: Role, secret: string, ttlSeconds = 3600) {
  const claims: Claims = { sub: username, role };
  return jwt.sign(claims, secret, { expiresIn: ttlSeconds });
}
export function verifyJWT(token: string, secret: string): Claims | null {
  try { return jwt.verify(token, secret) as Claims; } catch { return null; }
}

// TOTP helper (RFC 6238)
export function verifyTOTP(token: string, secret: string): boolean {
  try { return authenticator.verify({ token, secret }); } catch { return false; }
}
