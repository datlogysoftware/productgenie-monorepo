
"use client";
import { useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";
export default function Home(){
  const [url,setUrl]=useState(""); const [result,setResult]=useState<any>(null); const [id,setId]=useState<string|null>(null);
  async function analyze(){
    const r = await fetch(`${API_BASE}/v1/analyze`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url,lang:"tr"})}).then(r=>r.json());
    setId(r.id);
    for(let i=0;i<15;i++){ const a = await fetch(`${API_BASE}/v1/analyses/${r.id}`).then(r=>r.json()); setResult(a); await new Promise(s=>setTimeout(s,1000)); }
  }
  return (<main className="mx-auto max-w-2xl py-12">
    <h1 className="text-3xl font-bold mb-2">ProductGenie</h1>
    <p className="mb-6 text-sm text-gray-600">Satın almadan önce kontrol et — güvenle alışveriş yap.</p>
    <div className="flex gap-2"><input className="flex-1 border rounded px-3 py-2" value={url} onChange={e=>setUrl(e.target.value)} placeholder="Ürün URL'si" /><button onClick={analyze} className="px-4 py-2 bg-black text-white rounded">Analiz Et</button></div>
    {result && (<div className="mt-8 border rounded p-4 bg-white">
      
        <h2 className="font-semibold mb-2">Skor: {result.totalScore} / 5</h2>
        <div className="flex items-center gap-2 mb-2">
          <div aria-label="stars" className="text-amber-500 text-xl">{'★'.repeat(Math.round(result.totalScore))}{'☆'.repeat(5-Math.round(result.totalScore))}</div>
          <span className="text-xs bg-green-100 text-green-700 rounded px-2 py-0.5">Güven bandı (MVP)</span>
        </div>
        
      <ul className="text-sm grid grid-cols-2 gap-2">
        <li>Orijinallik: {result.criteria.authenticity}</li><li>Satıcı: {result.criteria.seller}</li>
        <li>Mağaza: {result.criteria.store}</li><li>Fiyat: {result.criteria.price}</li>
        <li>Yorum: {result.criteria.review}</li>
      </ul>
      <div className="mt-3"><h3 className="font-medium">Olumlu</h3><ul className="list-disc ml-6 text-sm">{result.positives?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul></div>
      <div className="mt-3"><h3 className="font-medium">Dikkat</h3><ul className="list-disc ml-6 text-sm">{result.cautions?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul></div>
    </div>)}
  {id && (<div className="mt-4"><a className="underline text-blue-600" href={`${API_BASE}/v1/analyses/${id}/report.pdf`} target="_blank" rel="noreferrer">PDF indir</a></div>)}
  </main>);
}
