
import * as cheerio from "cheerio";
import { ParserKit, ParseResult } from "../contracts";

export const AmazonTRKit: ParserKit = {
  domain: "amazon.com.tr",
  testUrls: ["https://www.amazon.com.tr/dp/EXAMPLE"],
  parse: (html: string, url: string): ParseResult => {
    const $ = cheerio.load(html);
    const title = $("#productTitle").text().trim() || $("h1").first().text().trim();
    const priceText = $("#corePriceDisplay_desktop_feature_div .a-price .a-offscreen, .a-price .a-offscreen").first().text().replace(/[^\d.,]/g, "");
    const price = Number((priceText || "0").replace(".", "").replace(",", ".").match(/\d+(?:\.\d+)?/)?.[0] || 0);
    const rating = Number($("#acrPopover").attr("title")?.replace(/[^\d.,]/g, "").replace(",", ".") || 0);
    const reviewCount = Number($("#acrCustomerReviewText").text().replace(/\D/g, "") || 0);
    return { title, price: { value: price, currency: "TRY" }, rating, reviewCount };
  }
};
