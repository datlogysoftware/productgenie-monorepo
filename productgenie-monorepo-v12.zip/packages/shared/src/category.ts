
export type Category = "default" | "electronics" | "fashion" | "cosmetics" | "grocery";

const LEX: Record<Category, string[]> = {
  electronics: ["iphone","samsung","xiaomi","tv","television","laptop","lenovo","asus","msi","kulaklık","headphone","airpods","playstation","ps5","nintendo","monitor","ssd","hdd","macbook","ipad"],
  fashion: ["elbise","tshirt","t-shirt","pantolon","sneaker","ayakkabı","çanta","aksesuar","gömlek","etek","triko","sweatshirt","mont","ceket","yelek"],
  cosmetics: ["parfüm","parfum","kolonya","serum","krem","maskara","ruj","fondöten","tonik","güneş kremi","sunscreen","şampuan","sampuan"],
  grocery: ["pirinç","bulgur","zeytinyağı","zeytinyagi","un","şeker","seker","kahve","çay","cay","makarna","yağ","yag","bakliyat","peynir"]
};

export function detectCategory(texts: string[]): Category {
  const hay = (texts.join(" ").toLowerCase());
  for (const [cat, keys] of Object.entries(LEX)) {
    for (const k of keys) { if (hay.includes(k)) return cat as Category; }
  }
  return "default";
}
