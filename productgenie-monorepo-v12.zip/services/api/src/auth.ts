
import type { Request, Response, NextFunction } from "express";
import { verifyJWT, type Claims } from "@productgenie/auth";

export function requireRole(role: "admin" | "analyst") {
  return (req: Request, res: Response, next: NextFunction) => {
    const hdr = req.headers.authorization || "";
    const token = hdr.startsWith("Bearer ") ? hdr.slice(7) : "";
    const secret = process.env.JWT_SECRET || "dev-secret";
    const claims = token ? verifyJWT(token, secret) : null;
    if (!claims || (role === "admin" && claims.role !== "admin")) return res.status(401).json({ error: "unauthorized" });
    (req as any).claims = claims as Claims;
    next();
  };
}
