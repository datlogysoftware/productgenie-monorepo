
"use client";
import { useEffect, useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";

export default function Analyses(){
  const [items, setItems] = useState<any[]>([]);
  const [err, setErr] = useState("");

  async function load(){
    setErr("");
    const token = localStorage.getItem("pg_admin_jwt") || "";
    const r = await fetch(`${API_BASE}/v1/admin/analyses?limit=200`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    if (!r.ok) { setErr("auth veya ağ hatası"); return; }
    const j = await r.json();
    setItems(j.items || []);
  }

  useEffect(()=>{ load(); }, []);

  return (<main style={{maxWidth:1000,margin:'40px auto'}}>
    <h1 style={{fontSize:22,fontWeight:700,marginBottom:12}}>Analizler</h1>
    <button onClick={load} style={{padding:'8px 12px', border:'1px solid #ddd', borderRadius:8}}>Yenile</button>
    {err && <p style={{color:'#b91c1c'}}>{err}</p>}
    <table style={{width:'100%',marginTop:16,borderCollapse:'collapse'}}>
      <thead><tr><th align="left">Tarih</th><th align="left">URL</th><th align="left">Skor</th></tr></thead>
      <tbody>
        {items.map((x:any)=>(
          <tr key={x.id} style={{borderTop:'1px solid #eee'}}>
            <td style={{padding:8}}>{new Date(x.createdAt).toLocaleString()}</td>
            <td style={{padding:8}}>{x.url}</td>
            <td style={{padding:8}}>{x.totalScore}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </main>);
}
