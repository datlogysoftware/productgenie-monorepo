
"use client";
import { useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";

export default function Login(){
  const [username, setU] = useState("admin");
  const [password, setP] = useState("admin");
  const [code, setC] = useState("");
  const [err, setErr] = useState("");

  async function submit(e:any){
    e.preventDefault();
    setErr("");
    const r = await fetch(`${API_BASE}/v1/admin/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, code: code || undefined })
    });
    const j = await r.json();
    if (!r.ok) { setErr(j.error || "login_failed"); return; }
    localStorage.setItem("pg_admin_jwt", j.token);
    location.href = "/analyses";
  }

  return (<main style={{maxWidth:420,margin:'60px auto', background:'#fff', padding:24, borderRadius:12, boxShadow:'0 1px 6px rgba(0,0,0,.05)'}}>
    <h1 style={{fontSize:22,fontWeight:700,marginBottom:12}}>Admin Girişi</h1>
    {err && <p style={{color:'#b91c1c'}}>{err}</p>}
    <form onSubmit={submit} style={{display:'grid', gap:12}}>
      <input placeholder="Kullanıcı adı" value={username} onChange={e=>setU(e.target.value)} />
      <input placeholder="Şifre" type="password" value={password} onChange={e=>setP(e.target.value)} />
      <input placeholder="MFA Kodu (opsiyonel)" value={code} onChange={e=>setC(e.target.value)} />
      <button type="submit" style={{padding:'10px 12px', background:'#111', color:'#fff', borderRadius:8}}>Giriş</button>
    </form>
  </main>);
}
