
"use client";
import { useState } from "react";
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:3001";
export default function Login(){
  const [email,setE]=useState(""); const [password,setP]=useState(""); const [err,setErr]=useState("");
  async function submit(e:any){ e.preventDefault(); setErr("");
    const r=await fetch(`${API_BASE}/v1/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});
    const j=await r.json(); if(!r.ok){ setErr(j.error||"login_failed"); return;}
    localStorage.setItem("pg_user_jwt", j.token); localStorage.setItem("pg_user_premium", j.premium?'1':'0'); location.href="/";
  }
  return (<main className="mx-auto max-w-sm py-12"><h1 className="text-2xl font-bold mb-4">Giriş</h1>
    {err && <p className="text-red-600">{err}</p>}
    <form onSubmit={submit} className="grid gap-2">
      <input className="border rounded px-3 py-2" placeholder="E-posta" value={email} onChange={e=>setE(e.target.value)} />
      <input className="border rounded px-3 py-2" placeholder="Şifre" type="password" value={password} onChange={e=>setP(e.target.value)} />
      <button className="bg-black text-white rounded px-3 py-2" type="submit">Giriş yap</button>
    </form>
    <p className="text-sm mt-3">Hesabın yok mu? <a className="underline" href="/register">Kayıt ol</a></p>
  </main>);
}
