
"use client";
import { useState } from "react";

export default function Home() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<any>(null);
  const [id, setId] = useState<string | null>(null);

  async function analyze() {
    setResult(null);
    const r = await fetch("http://localhost:3001/v1/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, lang: "tr" })
    }).then(r => r.json());
    setId(r.id);
    setTimeout(fetchResult, 600);
  }

  async function fetchResult() {
    if (!id) return;
    const r = await fetch(`http://localhost:3001/v1/analyses/${id}`).then(r => r.json());
    setResult(r);
  }

  return (
    <main className="mx-auto max-w-2xl py-12">
      <h1 className="text-3xl font-bold mb-2">ProductGenie</h1>
      <p className="mb-6 text-sm text-gray-600">Satın almadan önce kontrol et — güvenle alışveriş yap.</p>
      <div className="flex gap-2">
        <input className="flex-1 border rounded px-3 py-2" value={url} onChange={e=>setUrl(e.target.value)} placeholder="Ürün URL'si yapıştırın" />
        <button onClick={analyze} className="px-4 py-2 bg-black text-white rounded">Analiz Et</button>
      </div>
      {result && (
        <div className="mt-8 border rounded p-4 bg-white">
          <h2 className="font-semibold mb-2">Skor: {result.totalScore} / 5</h2>
          <ul className="text-sm grid grid-cols-2 gap-2">
            <li>Orijinallik: {result.criteria.authenticity}</li>
            <li>Satıcı: {result.criteria.seller}</li>
            <li>Mağaza: {result.criteria.store}</li>
            <li>Fiyat: {result.criteria.price}</li>
            <li>Yorum: {result.criteria.review}</li>
          </ul>
          <div className="mt-3">
            <h3 className="font-medium">Olumlu</h3>
            <ul className="list-disc ml-6 text-sm">{result.positives?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul>
          </div>
          <div className="mt-3">
            <h3 className="font-medium">Dikkat</h3>
            <ul className="list-disc ml-6 text-sm">{result.cautions?.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul>
          </div>
        </div>
      )}
    </main>
  );
}
