
export function normalizePrice(value: number, currency: string) {
  return { value, currency: currency.toUpperCase() };
}
export function normalizeText(s: string) {
  return s.replace(/\s+/g, " ").trim();
}
