
import { z } from "zod";
export const CriteriaSchema = z.object({
  authenticity: z.number().min(0).max(100),
  seller: z.number().min(0).max(100),
  store: z.number().min(0).max(100),
  price: z.number().min(0).max(100),
  review: z.number().min(0).max(100)
});
export type Criteria = z.infer<typeof CriteriaSchema>;
export interface Analysis {
  id: string; url: string; criteria: Criteria; totalScore: number;
  positives: string[]; cautions: string[];
  explain: { key: keyof Criteria; why: string }[]; createdAt: string;
}
export function computeStars(c: Criteria): number {
  const weighted = 0.25*c.review + 0.25*c.authenticity + 0.20*c.seller + 0.15*c.store + 0.15*c.price;
  return Math.round(((weighted/20) * 10)) / 10;
}
