
# ProductGenie Monorepo (MVP Scaffold)

This is a production-grade scaffold for ProductGenie with pnpm workspaces.

## Quick Start

```bash
corepack enable
corepack prepare pnpm@latest --activate
pnpm install
docker compose -f infra/docker/docker-compose.yml up -d
pnpm --filter services/api dev
pnpm --filter apps/web dev
pnpm --filter workers/extractor dev
```
