
import { chromium } from "playwright";
import * as cheerio from "cheerio";
import pino from "pino";
import { normalizePrice } from "@productgenie/pcms";

const log = pino({ name: "extractor" });

export async function extractUrl(url: string) {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ userAgent: "ProductGenieBot/0.1 (+https://productgenie.example/bot)" });
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
  const html = await page.content();
  await browser.close();

  const $ = cheerio.load(html);
  const title = $("title").first().text().trim() || "unknown";
  const priceText = $('[class*="price" i]').first().text().replace(/[^\d.,]/g, "");
  const price = Number((priceText || "0").replace(",", ".").match(/\d+(?:\.\d+)?/)?.[0] || 0);
  const normalized = normalizePrice(price, "TRY");
  return { title, price: normalized, snapshotBytes: html.length };
}

if (import.meta.main) {
  const url = process.argv[2] || "https://example.com";
  extractUrl(url).then(r => { log.info({ r }, "extracted"); }).catch(e => { log.error(e); process.exit(1); });
}
