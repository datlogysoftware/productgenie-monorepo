
import express from "express";
import cors from "cors";
import pino from "pino";
import { randomUUID } from "node:crypto";
import { computeStars, type Analysis } from "@productgenie/shared";

const app = express();
const log = pino({ name: "api" });
app.use(cors()); app.use(express.json());

const store = new Map<string, Analysis>();

app.post("/v1/analyze", (req, res) => {
  const { url, lang = "tr" } = req.body || {};
  if (!url) return res.status(400).json({ error: "url is required" });
  const id = randomUUID();
  const criteria = { authenticity: 60, seller: 65, store: 70, price: 62, review: 68 };
  const analysis: Analysis = {
    id, url, criteria,
    totalScore: computeStars(criteria),
    positives: ["Yorum kalitesi iyi", "Mağaza puanı ortalama üstü", "Fiyat oynaklığı düşük"],
    cautions: ["Satıcı yeni", "Orijinallik kanıtı sınırlı", "Fiyat rekabetçiliği orta"],
    explain: [{ key: "authenticity", why: "marka kataloğu eşleşmesi zayıf" }],
    createdAt: new Date().toISOString()
  };
  store.set(id, analysis);
  log.info({ id, url, lang }, "analysis created");
  res.json({ id, status: "processing" });
});

app.get("/v1/analyses/:id", (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: "not found" });
  res.json(a);
});

app.get("/v1/status", (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

const port = process.env.PORT || 3001;
app.listen(port, () => log.info(`API listening on :${port}`));
