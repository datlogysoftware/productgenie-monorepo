
import express from "express";
import cors from "cors";
import pino from "pino";
import { randomUUID } from "node:crypto";
import { computeStars, type Analysis } from "@productgenie/shared";
import { Queue } from "@productgenie/queue";

const app = express();
const log = pino({ name: "api" });
app.use(cors()); app.use(express.json());

// rate limit
const rlStore = new Map<string, { count: number; reset: number }>();
function rateLimit(req: any, res: any, next: any) {
  const key = (req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anon') + ':analyze';
  const now = Date.now();
  const item = rlStore.get(key) || { count: 0, reset: now + 60_000 };
  if (now > item.reset) { item.count = 0; item.reset = now + 60_000; }
  item.count += 1; rlStore.set(key, item);
  if (item.count > 30) return res.status(429).json({ error: "rate_limited", retryAfterMs: item.reset - now });
  next();
}

const queue = new Queue(process.env.REDIS_URL || "redis://127.0.0.1:6379"); queue.init();

// in-memory store (placeholder if Mongo not present in this minimal retry)
const store = new Map<string, Analysis>();

app.post("/v1/analyze", rateLimit, async (req, res) => {
  const { url, lang = "tr" } = req.body || {};
  if (!url) return res.status(400).json({ error: "url is required" });
  const id = randomUUID();
  const criteria = { authenticity: 60, seller: 65, store: 70, price: 62, review: 68 };
  const analysis: Analysis = { id, url, criteria, totalScore: computeStars(criteria), positives: [], cautions: [], explain: [], createdAt: new Date().toISOString() };
  store.set(id, analysis);
  await queue.add({ id, url, lang });
  res.json({ id, status: "processing" });
});

app.get("/v1/analyses/:id", (req, res) => {
  const a = store.get(req.params.id);
  if (!a) return res.status(404).json({ error: "not found" });
  res.json(a);
});

app.post("/v1/ingest/:id", (req, res) => {
  const token = req.header("x-ingest-token");
  if (!process.env.INGEST_TOKEN || token !== process.env.INGEST_TOKEN) {
    return res.status(401).json({ error: "unauthorized" });
  }
  const { id } = req.params;
  const prev = store.get(id);
  if (!prev) return res.status(404).json({ error: "not found" });
  const patch = req.body || {};
  const merged: Analysis = { ...prev, ...patch, totalScore: patch.criteria ? computeStars(patch.criteria) : prev.totalScore };
  store.set(id, merged);
  res.json({ ok: true });
});

app.get("/v1/admin/analyses", (req, res) => {
  const token = req.header("x-admin-token");
  if (!process.env.ADMIN_TOKEN || token !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({ error: "unauthorized" });
  }
  const items = Array.from(store.values()).sort((a: any, b: any)=> b.createdAt.localeCompare(a.createdAt)).slice(0, 100);
  res.json({ items });
});

const port = process.env.PORT || 3001;
app.listen(port, () => log.info(`API listening on :${port}`));
