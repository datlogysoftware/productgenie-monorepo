
import jwt from "jsonwebtoken";

export type AdminClaims = { sub: string; role: "admin"; iat?: number; exp?: number };

export function signAdminJWT(username: string, secret: string, ttlSeconds = 3600) {
  const claims: AdminClaims = { sub: username, role: "admin" };
  return jwt.sign(claims, secret, { expiresIn: ttlSeconds });
}

export function verifyAdminJWT(token: string, secret: string): AdminClaims | null {
  try {
    const decoded = jwt.verify(token, secret) as AdminClaims;
    if (decoded.role !== "admin") return null;
    return decoded;
  } catch { return null; }
}
