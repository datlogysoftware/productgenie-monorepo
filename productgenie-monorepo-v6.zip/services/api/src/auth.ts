
import type { Request, Response, NextFunction } from "express";
import { verifyAdminJWT } from "@productgenie/auth";

export function adminGuard(req: Request, res: Response, next: NextFunction) {
  const hdr = req.headers.authorization || "";
  const token = hdr.startsWith("Bearer ") ? hdr.slice(7) : "";
  const secret = process.env.JWT_SECRET || "dev-secret";
  const claims = token ? verifyAdminJWT(token, secret) : null;
  if (!claims) return res.status(401).json({ error: "unauthorized" });
  // @ts-ignore
  req.admin = claims;
  next();
}
